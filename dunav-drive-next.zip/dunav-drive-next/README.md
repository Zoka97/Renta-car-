# Dunav Drive – rent a car Novi Sad (Next.js 16 + Supabase)

## Pokretanje
1. **Supabase**: napravite projekat → SQL Editor → nalepite i pokrenite `supabase/schema.sql` (tabele, RLS, početni podaci, bucket `cars`), a zatim i `supabase/update-2.sql` (engleski sadržaj i vesti).
2. **Admin nalog**: Authentication → Users → *Add user* (email + lozinka, štiklirajte auto-confirm). Taj email upišite kao `ADMIN_EMAIL`.
3. `cp .env.example .env.local` i popunite ključeve (Project Settings → API). `SUPABASE_SERVICE_ROLE_KEY` je tajni ključ – nikad ga ne stavljajte u `NEXT_PUBLIC_*`.
4. `npm install` pa `npm run dev` → sajt na http://localhost:3000, admin na /admin/login.

## Deploy
Vercel → Import repo → iste env promenljive → povežite domen i postavite `NEXT_PUBLIC_SITE_URL`.
Zatim u Google Search Console dodajte `https://vaš-domen/sitemap.xml`.

## Napomene
- Email sa PDF potvrdom (klijentu i vama) šalje se samo ako je podešen `RESEND_API_KEY` (resend.com, potvrdite domen).
- Slike vozila u adminu: Server Actions imaju podrazumevani limit tela zahteva od 1 MB. Za veće slike podignite `bodySizeLimit` (docs: Next.js → serverActions).
- Admin se proverava u kodu (`requireAdmin`) u layoutu i u svakoj akciji, a ne samo u `proxy.ts`.
- PDF koristi font DejaVu Sans (slobodna licenca) iz `assets/fonts`, zbog slova č, ć, š, ž, đ.
- Podaci firme (PIB, račun, adresa, telefon) u `schema.sql` su rezervisani – izmenite ih u adminu.

## Jezici i vesti
- Srpski je na `/`, engleski na `/en` (`/en/fleet/...`, `/en/news/...`). Stranice imaju `hreflang` i canonical, a sitemap sadrži obe verzije.
- Engleski tekstovi se uređuju u adminu: *Sadržaj i podaci* (blok „English”) i polja „EN” u *Vesti*. Naziv, menjač i gorivo vozila prevode se automatski (Automatski → Automatic itd.).
- Vest bez engleskog naslova se prikazuje samo na srpskom.
- PDF račun je na srpskom (domaći račun).
