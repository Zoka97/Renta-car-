import type { NextConfig } from 'next'

const config: NextConfig = {
  // fontovi za PDF moraju da stignu u serverless funkciju
  outputFileTracingIncludes: { '/api/**/*': ['./assets/fonts/**'] },
  images: { remotePatterns: [{ protocol: 'https', hostname: '*.supabase.co' }] },
}
export default config
