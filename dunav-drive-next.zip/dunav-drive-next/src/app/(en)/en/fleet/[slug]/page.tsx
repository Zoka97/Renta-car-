import { CarDetail, carMeta } from '@/components/pages'
import { getCars } from '@/lib/data'

export const revalidate = 60
type Props = { params: Promise<{ slug: string }> }
export async function generateStaticParams() { return (await getCars()).map((c) => ({ slug: c.slug })) }
export async function generateMetadata({ params }: Props) { return carMeta('en', (await params).slug) }
export default async function Page({ params }: Props) { return <CarDetail lang="en" slug={(await params).slug} /> }
