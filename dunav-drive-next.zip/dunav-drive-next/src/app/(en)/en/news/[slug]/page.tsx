import { PostDetail, postMeta } from '@/components/pages'

export const revalidate = 60
type Props = { params: Promise<{ slug: string }> }
export async function generateMetadata({ params }: Props) { return postMeta('en', (await params).slug) }
export default async function Page({ params }: Props) { return <PostDetail lang="en" slug={(await params).slug} /> }
