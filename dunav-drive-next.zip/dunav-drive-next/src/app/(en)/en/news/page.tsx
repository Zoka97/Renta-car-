import { NewsIndex, newsMeta } from '@/components/pages'

export const revalidate = 60
export const generateMetadata = () => newsMeta('en')
export default function Page() { return <NewsIndex lang="en" /> }
