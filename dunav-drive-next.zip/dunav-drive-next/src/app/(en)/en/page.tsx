import { Home, homeMeta } from '@/components/pages'

export const revalidate = 60
export const generateMetadata = () => homeMeta('en')
export default function Page() { return <Home lang="en" /> }
