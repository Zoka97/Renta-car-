import '@/app/globals.css'
import SiteShell from '@/components/SiteShell'
import { rootMeta } from '@/lib/meta'

export const revalidate = 60
export const generateMetadata = () => rootMeta('sr')
export default function Layout({ children }: { children: React.ReactNode }) {
  return <html lang="sr"><body><SiteShell lang="sr">{children}</SiteShell></body></html>
}
