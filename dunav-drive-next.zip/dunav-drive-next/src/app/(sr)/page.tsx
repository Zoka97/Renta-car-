import { Home, homeMeta } from '@/components/pages'

export const revalidate = 60
export const generateMetadata = () => homeMeta('sr')
export default function Page() { return <Home lang="sr" /> }
