'use server'
import { serviceDb } from '@/lib/supabase'
import { getSettings, money, type FormState, type Reservation } from '@/lib/data'
import { buildPdf } from '@/lib/pdf'
import { T, type Lang } from '@/lib/i18n'

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`)

/** "2026-12-01T10:00" (vreme u Novom Sadu) -> tačan trenutak, bez obzira na vremensku zonu servera. */
function belgrade(local: string) {
  const asUtc = new Date(local + 'Z')
  const off = new Date(asUtc.toLocaleString('en-US', { timeZone: 'Europe/Belgrade' })).getTime() - new Date(asUtc.toLocaleString('en-US', { timeZone: 'UTC' })).getTime()
  return new Date(asUtc.getTime() - off)
}

async function mail(to: string, subject: string, html: string, attachment?: { filename: string; content: string }) {
  const key = process.env.RESEND_API_KEY
  if (!key || !to) return
  await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: process.env.RESEND_FROM, to: [to], subject, html, attachments: attachment ? [attachment] : undefined }),
  })
}

async function notify(r: Reservation, lang: Lang) {
  const s = await getSettings()
  const pdf = Buffer.from(await buildPdf(r, s)).toString('base64')
  const body = `<p>Rezervacija <b>${esc(r.no)}</b>: ${esc(r.car_name)}, ${r.days} dan(a), ${money(r.total)}</p><p>${esc(r.name)} · ${esc(r.phone)} · ${esc(r.email)}</p>`
  await Promise.all([
    mail(r.email, lang === 'en' ? `Booking confirmation ${r.no} – ${s.brand}` : `Potvrda rezervacije ${r.no} – ${s.brand}`, `<p>${lang === 'en' ? 'Thank you' : 'Hvala'}, ${esc(r.name)}!</p>${body}<p>${lang === 'en' ? 'Contact' : 'Kontakt'}: ${esc(s.phone)}</p>`, { filename: `potvrda-${r.no}.pdf`, content: pdf }),
    mail(process.env.ADMIN_EMAIL ?? '', `Nova rezervacija ${r.no}`, body),
  ])
}

export async function createReservation(_prev: FormState, fd: FormData): Promise<FormState> {
  const g = (k: string) => String(fd.get(k) ?? '').trim()
  const lang: Lang = g('lang') === 'en' ? 'en' : 'sr', t = T[lang]
  const db = serviceDb()
  const { data: car } = await db.from('cars').select('name,price').eq('id', g('car')).single()
  const from = belgrade(g('from')), to = belgrade(g('to'))
  if (!car || isNaN(+from) || isNaN(+to) || !(to > from) || +from < Date.now() - 864e5) return { ok: false, msg: t.badDates }
  const name = g('name'), phone = g('phone'), email = g('email')
  if (name.length < 2 || phone.length < 6 || !/^\S+@\S+\.\S+$/.test(email)) return { ok: false, msg: t.badContact }
  const days = Math.max(1, Math.ceil((+to - +from) / 864e5))
  const no = 'R' + new Date().toISOString().slice(2, 10).replace(/-/g, '') + '-' + Math.floor(1000 + Math.random() * 9000)
  const { data: row, error } = await db.from('reservations')
    .insert({ no, car_name: car.name, price: car.price, days, total: days * car.price, from_at: from.toISOString(), to_at: to.toISOString(), name, phone, email })
    .select().single()
  if (error || !row) return { ok: false, msg: t.fail }
  try { await notify(row as Reservation, lang) } catch {}
  return { ok: true, msg: t.thanks(no) }
}
