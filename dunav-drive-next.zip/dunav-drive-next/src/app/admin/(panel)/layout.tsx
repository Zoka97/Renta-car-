import type { Metadata } from 'next'
import Link from 'next/link'
import { requireAdmin } from '@/lib/auth'
import { logout } from '../actions'

export const metadata: Metadata = { title: 'Admin', robots: { index: false, follow: false } }

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin()
  return (
    <>
      <header><div className="w bar">
        <b className="lg">Admin panel</b>
        <nav><Link href="/admin">Rezervacije</Link><Link href="/admin/vozila">Vozila</Link><Link href="/admin/vesti">Vesti</Link><Link href="/admin/podesavanja">Sadržaj i podaci</Link><Link href="/">Sajt ↗</Link>
          <form action={logout}><button className="btn">Odjava</button></form></nav>
      </div></header>
      <main>{children}</main>
    </>
  )
}
