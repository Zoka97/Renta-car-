import { fmt, money, type Reservation } from '@/lib/data'
import { serviceDb } from '@/lib/supabase'
import { deleteReservation, setStatus } from '../actions'

export default async function Reservations() {
  const { data } = await serviceDb().from('reservations').select('*').order('created_at', { ascending: false })
  const list = (data ?? []) as Reservation[]
  return (
    <section className="w">
      <h1>Rezervacije ({list.length})</h1>
      <div className="stack">
        {list.length === 0 && <p>Još nema rezervacija.</p>}
        {list.map((r) => (
          <div key={r.id} className="card">
            <b>{r.no}</b> · {r.car_name} · {r.days} d · <b>{money(r.total)}</b><br />
            {r.name} · {r.phone} · {r.email}<br /><small>{fmt(r.from_at)} → {fmt(r.to_at)}</small>
            <div className="row">
              <form action={setStatus} className="row">
                <input type="hidden" name="id" value={r.id} />
                <select name="status" defaultValue={r.status}>{['nova', 'potvrđena', 'otkazana'].map((x) => <option key={x}>{x}</option>)}</select>
                <button className="btn">Sačuvaj</button>
              </form>
              <a className="btn" href={`/api/reservations/${r.id}/pdf`} target="_blank" rel="noreferrer">PDF račun</a>
              <form action={deleteReservation}><input type="hidden" name="id" value={r.id} /><button className="btn">Obriši</button></form>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
