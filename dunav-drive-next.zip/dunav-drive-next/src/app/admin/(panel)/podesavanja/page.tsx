import Field from '@/components/Field'
import { getSettings, SETTING_FIELDS, SETTING_FIELDS_EN } from '@/lib/data'
import { saveSettings } from '../../actions'

export const dynamic = 'force-dynamic'

export default async function Settings() {
  const s = await getSettings()
  const row = s as unknown as Record<string, string>
  return (
    <section className="w">
      <h1>Sadržaj i podaci firme</h1>
      <form action={saveSettings} className="card stack">
        <div className="g2">{SETTING_FIELDS.map(([k, l]) => <Field key={k} label={l} name={k} def={row[k]} />)}</div>
        <label>O nama<textarea name="about" rows={5} defaultValue={s.about} /></label>
        <label>Prednosti (naslov | opis, po jedna u redu)<textarea name="why" rows={5} defaultValue={s.why.map((a) => a.join(' | ')).join('\n')} /></label>
        <label>Česta pitanja (pitanje | odgovor, po jedno u redu)<textarea name="faq" rows={7} defaultValue={s.faq.map((a) => a.join(' | ')).join('\n')} /></label>
        <h2>English (EN)</h2>
        <div className="g2">{SETTING_FIELDS_EN.map(([k, l]) => <Field key={k} label={l} name={k} def={row[k]} />)}</div>
        <label>About us (EN)<textarea name="about_en" rows={5} defaultValue={s.about_en ?? ''} /></label>
        <label>Why us (EN) – title | description, one per line<textarea name="why_en" rows={5} defaultValue={(s.why_en ?? []).map((a) => a.join(' | ')).join('\n')} /></label>
        <label>FAQ (EN) – question | answer, one per line<textarea name="faq_en" rows={7} defaultValue={(s.faq_en ?? []).map((a) => a.join(' | ')).join('\n')} /></label>
        <button className="btn">Sačuvaj izmene</button>
      </form>
    </section>
  )
}
