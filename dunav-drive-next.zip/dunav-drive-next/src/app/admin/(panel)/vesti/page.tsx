import Field from '@/components/Field'
import { fmt, type Post } from '@/lib/data'
import { serviceDb } from '@/lib/supabase'
import { deletePost, savePost } from '../../actions'

export const dynamic = 'force-dynamic'

export default async function Posts() {
  const { data } = await serviceDb().from('posts').select('*').order('published_at', { ascending: false })
  const posts = (data ?? []) as Post[]
  const form = (p?: Post) => (
    <form key={p?.id ?? 'new'} action={savePost} className="card stack">
      {p && <input type="hidden" name="id" value={p.id} />}
      {p && <small>{p.published ? 'Objavljeno' : 'Nacrt'} · {fmt(p.published_at)} · /vesti/{p.slug}</small>}
      <Field label="Naslov" name="title" def={p?.title} /><Field label="Kratak opis (meta description, 150–160 znakova)" name="excerpt" def={p?.excerpt} />
      <label>Tekst (pasuse razdvojite praznim redom)<textarea name="body" rows={8} defaultValue={p?.body ?? ''} /></label>
      <Field label="Title (EN, opciono)" name="title_en" def={p?.title_en} /><Field label="Excerpt (EN)" name="excerpt_en" def={p?.excerpt_en} />
      <label>Body (EN) – ako je prazno, vest se ne prikazuje na engleskom<textarea name="body_en" rows={6} defaultValue={p?.body_en ?? ''} /></label>
      <label>Naslovna slika (do 1 MB)<input type="file" name="image" accept="image/*" /></label>
      <label className="check"><input type="checkbox" name="published" defaultChecked={p?.published ?? true} /> Objavljeno</label>
      <div className="row"><button className="btn">{p ? 'Sačuvaj' : '+ Dodaj vest'}</button></div>
    </form>
  )
  return (
    <section className="w">
      <h1>Vesti</h1>
      <div className="stack">
        <h2>Nova vest</h2>{form()}
        {posts.map((p) => (
          <div key={p.id} className="stack">{form(p)}
            <form action={deletePost}><input type="hidden" name="id" value={p.id} /><button className="btn">Obriši „{p.title}”</button></form>
          </div>
        ))}
      </div>
    </section>
  )
}
