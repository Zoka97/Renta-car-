import Field from '@/components/Field'
import { getCars } from '@/lib/data'
import { deleteCar, saveCar } from '../../actions'

export const dynamic = 'force-dynamic'

export default async function Cars() {
  const cars = await getCars()
  const form = (c?: (typeof cars)[number]) => (
    <form key={c?.id ?? 'new'} action={saveCar} className="card stack">
      {c && <input type="hidden" name="id" value={c.id} />}
      {c?.image_url && /* eslint-disable-next-line @next/next/no-img-element */ <img src={c.image_url} alt={c.name} className="thumb" />}
      <div className="g2">
        <Field label="Naziv" name="name" def={c?.name} /><Field label="Cena €/dan" name="price" type="number" def={c?.price} />
        <Field label="Putnika" name="pax" type="number" def={c?.pax ?? 5} /><Field label="Kofera" name="bags" type="number" def={c?.bags ?? 2} />
        <Field label="Menjač" name="gear" def={c?.gear ?? 'Automatski'} /><Field label="Gorivo" name="fuel" def={c?.fuel ?? 'Benzin'} />
        <label>Slika (do 1 MB)<input type="file" name="image" accept="image/*" /></label>
      </div>
      <div className="row"><button className="btn">{c ? 'Sačuvaj' : '+ Dodaj vozilo'}</button></div>
    </form>
  )
  return (
    <section className="w">
      <h1>Vozila</h1>
      <div className="stack">
        {cars.map((c) => (
          <div key={c.id} className="stack">{form(c)}
            <form action={deleteCar}><input type="hidden" name="id" value={c.id} /><button className="btn">Obriši {c.name}</button></form>
          </div>
        ))}
        <h2>Novo vozilo</h2>{form()}
      </div>
    </section>
  )
}
