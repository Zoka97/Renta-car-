'use server'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { requireAdmin } from '@/lib/auth'
import { SETTING_FIELDS, SETTING_FIELDS_EN } from '@/lib/data'
import { serviceDb, sessionDb } from '@/lib/supabase'

const g = (fd: FormData, k: string) => String(fd.get(k) ?? '').trim()
const slugify = (s: string) => s.toLowerCase().replace(/đ/g, 'dj').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
const lines = (v: string) => v.split('\n').map((l) => l.trim()).filter(Boolean).map((l) => l.split('|').map((x) => x.trim()))
const refresh = () => { revalidatePath('/', 'layout'); revalidatePath('/admin', 'layout') }

export async function login(fd: FormData) {
  const db = await sessionDb()
  const { data, error } = await db.auth.signInWithPassword({ email: g(fd, 'email'), password: g(fd, 'password') })
  if (error || data.user?.email?.toLowerCase() !== process.env.ADMIN_EMAIL?.toLowerCase()) {
    await db.auth.signOut()
    redirect('/admin/login?err=1')
  }
  redirect('/admin')
}
export async function logout() {
  await (await sessionDb()).auth.signOut()
  redirect('/admin/login')
}
export async function setStatus(fd: FormData) {
  await requireAdmin()
  await serviceDb().from('reservations').update({ status: g(fd, 'status') }).eq('id', g(fd, 'id'))
  refresh()
}
export async function deleteReservation(fd: FormData) {
  await requireAdmin()
  await serviceDb().from('reservations').delete().eq('id', g(fd, 'id'))
  refresh()
}
export async function saveCar(fd: FormData) {
  await requireAdmin()
  const db = serviceDb(), id = g(fd, 'id'), name = g(fd, 'name')
  if (!name) return
  const row: Record<string, unknown> = { name, slug: slugify(name), pax: +g(fd, 'pax') || 5, bags: +g(fd, 'bags') || 0, gear: g(fd, 'gear'), fuel: g(fd, 'fuel'), price: +g(fd, 'price') || 0 }
  const file = fd.get('image') as File | null
  if (file && file.size) {
    const p = `${row.slug}-${Date.now()}.${(file.name.split('.').pop() || 'jpg').toLowerCase()}`
    const { error } = await db.storage.from('cars').upload(p, file, { contentType: file.type })
    if (!error) row.image_url = db.storage.from('cars').getPublicUrl(p).data.publicUrl
  }
  if (id) await db.from('cars').update(row).eq('id', id)
  else await db.from('cars').insert(row)
  refresh()
}
export async function deleteCar(fd: FormData) {
  await requireAdmin()
  await serviceDb().from('cars').delete().eq('id', g(fd, 'id'))
  refresh()
}
export async function saveSettings(fd: FormData) {
  await requireAdmin()
  const row: Record<string, unknown> = { about: g(fd, 'about'), why: lines(g(fd, 'why')), faq: lines(g(fd, 'faq')), about_en: g(fd, 'about_en'), why_en: lines(g(fd, 'why_en')), faq_en: lines(g(fd, 'faq_en')) }
  ;[...SETTING_FIELDS, ...SETTING_FIELDS_EN].forEach(([k]) => (row[k] = g(fd, k)))
  await serviceDb().from('settings').update(row).eq('id', 1)
  refresh()
}
export async function savePost(fd: FormData) {
  await requireAdmin()
  const db = serviceDb(), id = g(fd, 'id'), title = g(fd, 'title')
  if (!title) return
  const row: Record<string, unknown> = {
    title, excerpt: g(fd, 'excerpt'), body: g(fd, 'body'), title_en: g(fd, 'title_en') || null, excerpt_en: g(fd, 'excerpt_en') || null, body_en: g(fd, 'body_en') || null,
    published: fd.get('published') === 'on',
  }
  const file = fd.get('image') as File | null
  if (file && file.size) {
    const p = `vest-${Date.now()}.${(file.name.split('.').pop() || 'jpg').toLowerCase()}`
    const { error } = await db.storage.from('cars').upload(p, file, { contentType: file.type })
    if (!error) row.image_url = db.storage.from('cars').getPublicUrl(p).data.publicUrl
  }
  if (id) await db.from('posts').update(row).eq('id', id) // slug se ne menja, da linkovi ostanu isti
  else await db.from('posts').insert({ ...row, slug: slugify(title) })
  refresh()
}
export async function deletePost(fd: FormData) {
  await requireAdmin()
  await serviceDb().from('posts').delete().eq('id', g(fd, 'id'))
  refresh()
}
