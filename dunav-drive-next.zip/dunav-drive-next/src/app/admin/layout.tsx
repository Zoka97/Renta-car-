import '@/app/globals.css'

export default function AdminRoot({ children }: { children: React.ReactNode }) {
  return <html lang="sr"><body>{children}</body></html>
}
