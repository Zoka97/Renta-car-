import type { Metadata } from 'next'
import { login } from '../actions'

export const metadata: Metadata = { title: 'Prijava', robots: { index: false, follow: false } }

export default async function Login({ searchParams }: { searchParams: Promise<{ err?: string }> }) {
  const { err } = await searchParams
  return (
    <section className="w narrow">
      <h1>Admin prijava</h1>
      <form action={login} className="card stack">
        <label>Email<input name="email" type="email" required autoComplete="username" /></label>
        <label>Lozinka<input name="password" type="password" required autoComplete="current-password" /></label>
        {err && <p className="err">Pogrešni podaci za prijavu.</p>}
        <button className="btn">Prijavi se</button>
      </form>
    </section>
  )
}
