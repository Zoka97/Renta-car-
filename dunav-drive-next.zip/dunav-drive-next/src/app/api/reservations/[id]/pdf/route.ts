import { isAdmin } from '@/lib/auth'
import { getSettings, type Reservation } from '@/lib/data'
import { buildPdf } from '@/lib/pdf'
import { serviceDb } from '@/lib/supabase'

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin())) return new Response('Unauthorized', { status: 401 })
  const { id } = await params
  const { data } = await serviceDb().from('reservations').select('*').eq('id', id).single()
  if (!data) return new Response('Not found', { status: 404 })
  const r = data as Reservation
  const pdf = await buildPdf(r, await getSettings())
  return new Response(pdf as unknown as BodyInit, { headers: { 'Content-Type': 'application/pdf', 'Content-Disposition': `inline; filename="potvrda-${r.no}.pdf"` } })
}
