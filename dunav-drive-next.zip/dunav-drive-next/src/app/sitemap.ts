import type { MetadataRoute } from 'next'
import { getCars, getPosts, site } from '@/lib/data'
import { P } from '@/lib/i18n'

export const revalidate = 3600

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [cars, posts] = await Promise.all([getCars(), getPosts()])
  const u = (p: string) => site() + (p === '/' ? '' : p)
  // svaka stranica ima SR i EN adresu sa hreflang vezama
  const pair = (sr: string, en: string, priority: number, onlySr = false): MetadataRoute.Sitemap => {
    const alternates = onlySr ? undefined : { languages: { 'sr-RS': u(sr), en: u(en) } }
    return [{ url: u(sr), priority, alternates }, ...(onlySr ? [] : [{ url: u(en), priority, alternates }])]
  }
  return [
    ...pair('/', '/en', 1),
    ...pair(P.news('sr'), P.news('en'), 0.6),
    ...cars.flatMap((c) => pair(P.car('sr', c.slug), P.car('en', c.slug), 0.8)),
    ...posts.flatMap((p) => pair(P.post('sr', p.slug), P.post('en', p.slug), 0.5, !p.title_en)),
  ]
}
