'use client'
import { useActionState } from 'react'
import { createReservation } from '@/app/actions'
import { T, type Lang } from '@/lib/i18n'

export default function BookingForm({ cars, defaultCar, lang = 'sr' }: { cars: { id: string; name: string; price: number }[]; defaultCar?: string; lang?: Lang }) {
  const [state, action, pending] = useActionState(createReservation, null)
  const t = T[lang]
  return (
    <form id="rezervacija" action={action} className="card form" aria-label={t.bookTitle}>
      <input type="hidden" name="lang" value={lang} />
      <h2>{t.bookTitle}</h2>
      <label>{t.car}
        <select name="car" defaultValue={defaultCar}>{cars.map((c) => <option key={c.id} value={c.id}>{c.name} – {c.price} €/{t.day}</option>)}</select>
      </label>
      <label>{t.pickup}<input type="datetime-local" name="from" required /></label>
      <label>{t.ret}<input type="datetime-local" name="to" required /></label>
      <label>{t.name}<input name="name" required autoComplete="name" /></label>
      <label>{t.phone}<input name="phone" type="tel" required autoComplete="tel" /></label>
      <label>{t.email}<input name="email" type="email" required autoComplete="email" /></label>
      <button className="btn" disabled={pending}>{pending ? t.sending : t.send}</button>
      {state && <p role="status" className={state.ok ? 'ok' : 'err'}>{state.msg}</p>}
    </form>
  )
}
