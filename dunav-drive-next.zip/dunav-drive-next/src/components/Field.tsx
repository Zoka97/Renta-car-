export default function Field({ label, name, def, type = 'text' }: { label: string; name: string; def?: string | number | null; type?: string }) {
  return <label>{label}<input name={name} type={type} defaultValue={def ?? ''} /></label>
}
