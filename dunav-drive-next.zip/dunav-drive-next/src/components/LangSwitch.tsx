'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export default function LangSwitch({ lang }: { lang: 'sr' | 'en' }) {
  const p = usePathname()
  const to = lang === 'sr'
    ? (p === '/' ? '/en' : p.replace('/vozni-park/', '/en/fleet/').replace(/^\/vesti/, '/en/news'))
    : (p === '/en' ? '/' : p.replace('/en/fleet/', '/vozni-park/').replace(/^\/en\/news/, '/vesti'))
  return <Link href={to} hrefLang={lang === 'sr' ? 'en' : 'sr'} className="lang">{lang === 'sr' ? 'EN' : 'SR'}</Link>
}
