export default function Logo({ size = 38 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
      <rect width="48" height="48" rx="12" fill="#16406e" />
      <path d="M8 30Q24 6 40 30" fill="none" stroke="#f5a623" strokeWidth="3.5" strokeLinecap="round" />
      <path d="M24 18v12M16 21v9M32 21v9" stroke="#f5a623" strokeWidth="2" strokeLinecap="round" />
      <path d="M6 37q4.5-4 9 0t9 0t9 0t9 0" fill="none" stroke="#fff" strokeWidth="2.8" strokeLinecap="round" />
    </svg>
  )
}
