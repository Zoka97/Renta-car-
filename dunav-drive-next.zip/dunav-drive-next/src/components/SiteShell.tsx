import Link from 'next/link'
import Logo from './Logo'
import LangSwitch from './LangSwitch'
import { getSettings } from '@/lib/data'
import { P, T, type Lang } from '@/lib/i18n'

export default async function SiteShell({ lang, children }: { lang: Lang; children: React.ReactNode }) {
  const s = await getSettings(), t = T[lang], h = P.home(lang)
  return (
    <>
      <header><div className="w bar">
        <Link href={h} className="lg"><Logo />{s.brand}</Link>
        <nav aria-label={lang === 'en' ? 'Main navigation' : 'Glavna navigacija'}>
          <Link href={`${h}#vozni-park`}>{t.fleet}</Link><Link href={`${h}#o-nama`}>{t.about}</Link>
          <Link href={P.news(lang)}>{t.news}</Link><Link href={`${h}#kontakt`}>{t.contact}</Link>
          <LangSwitch lang={lang} /><Link className="btn" href={`${h}#rezervacija`}>{t.book}</Link>
        </nav>
      </div></header>
      <main>{children}</main>
      <footer>© {new Date().getFullYear()} {s.brand} · {s.addr}</footer>
    </>
  )
}
