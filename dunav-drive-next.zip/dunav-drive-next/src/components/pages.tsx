import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import BookingForm from './BookingForm'
import { getCars, getPosts, getSettings, site, type Car, type Post } from '@/lib/data'
import { alts } from '@/lib/meta'
import { P, T, tl, tx, type Lang } from '@/lib/i18n'

const json = (o: unknown) => <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(o).replace(/</g, '\\u003c') }} />
const light = (cars: Car[]) => cars.map(({ id, name, price }) => ({ id, name, price }))
const pv = (p: Post, l: Lang) => (l === 'en' ? { title: p.title_en, excerpt: p.excerpt_en, body: p.body_en } : { title: p.title, excerpt: p.excerpt, body: p.body })
const visible = (posts: Post[], l: Lang) => posts.filter((p) => (l === 'en' ? !!p.title_en : true))
const date = (d: string, l: Lang) => new Date(d).toLocaleDateString(T[l].locale, { dateStyle: 'long', timeZone: 'Europe/Belgrade' })

function Specs({ c, l }: { c: Car; l: Lang }) {
  const t = T[l]
  return <ul><li>{t.pax}: {c.pax}</li><li>{t.bags}: {c.bags}</li><li>{t.gear[c.gear] ?? c.gear}</li><li>{t.fuel[c.fuel] ?? c.fuel}</li></ul>
}
const Price = ({ c, l }: { c: Car; l: Lang }) => <div className="pr"><small>{T[l].from} </small>{c.price} €<small> {T[l].perDay}</small></div>

export async function homeMeta(lang: Lang): Promise<Metadata> {
  return { alternates: alts(lang, '/', '/en') }
}
export async function Home({ lang }: { lang: Lang }) {
  const [s, cars, allPosts] = await Promise.all([getSettings(), getCars(), getPosts()])
  const t = T[lang], faq = tl(s, 'faq', lang), why = tl(s, 'why', lang), posts = visible(allPosts, lang).slice(0, 3)
  return (
    <>
      {json({ '@context': 'https://schema.org', '@graph': [
        { '@type': 'AutoRental', name: s.brand, url: site(), description: `${tx(s, 'tag', lang)} – ${tx(s, 'sub', lang)}`, telephone: s.phone, email: s.email, priceRange: '€€', areaServed: 'Novi Sad', inLanguage: lang,
          address: { '@type': 'PostalAddress', streetAddress: s.addr, addressLocality: 'Novi Sad', addressCountry: 'RS' } },
        { '@type': 'FAQPage', mainEntity: faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a ?? '' } })) },
      ] })}
      <section className="hero"><div className="w">
        <p className="k">{tx(s, 'tag', lang)}</p><h1>{tx(s, 'hero', lang)}</h1><p>{tx(s, 'sub', lang)}</p>
        <BookingForm cars={light(cars)} lang={lang} />
      </div></section>
      <section id="vozni-park" className="w"><h2>{t.fleetTitle}</h2>
        <div className="grid">{cars.map((c) => (
          <article key={c.id} className="card car">
            {c.image_url ? <Image src={c.image_url} alt={`${lang === 'en' ? 'Car rental Novi Sad' : 'Rent a car Novi Sad'} – ${c.name}`} width={640} height={360} /> : <div className="ph">🚗</div>}
            <h3><Link href={P.car(lang, c.slug)}>{c.name}</Link></h3><Specs c={c} l={lang} /><Price c={c} l={lang} />
            <Link className="btn" href={P.car(lang, c.slug)}>{t.check}</Link>
          </article>
        ))}</div>
      </section>
      <section id="o-nama" className="w two">
        <div><h2>{t.about}</h2><p>{tx(s, 'about', lang)}</p></div>
        <div><h2>{t.whyTitle}</h2>{why.map(([a, d]) => <p key={a}><b>{a}</b><br />{d}</p>)}</div>
      </section>
      {posts.length > 0 && <section className="w"><h2>{t.latest}</h2><div className="grid">{posts.map((p) => <PostCard key={p.id} p={p} l={lang} />)}</div>
        <p><Link href={P.news(lang)}>{t.all}</Link></p></section>}
      <section className="w"><h2>{t.faqTitle}</h2>{faq.map(([q, a]) => <details key={q}><summary>{q}</summary><p>{a}</p></details>)}</section>
      <section id="kontakt" className="w"><h2>{t.contactTitle}</h2><div className="card">
        <p><b>{t.phone}:</b> <a href={`tel:${s.phone.replace(/[^\d+]/g, '')}`}>{s.phone}</a></p>
        <p><b>{t.email}:</b> <a href={`mailto:${s.email}`}>{s.email}</a></p><p><b>{t.address}:</b> {s.addr}</p><p><b>{t.hours}:</b> {s.hours}</p>
      </div></section>
    </>
  )
}

export async function carMeta(lang: Lang, slug: string): Promise<Metadata> {
  const c = (await getCars()).find((x) => x.slug === slug)
  if (!c) return {}
  const t = T[lang], en = lang === 'en'
  return {
    title: en ? `${c.name} – car rental Novi Sad from ${c.price} €/day` : `${c.name} – rent a car Novi Sad od ${c.price} €/dan`,
    description: en ? `Rent a ${c.name} in Novi Sad: ${(t.gear[c.gear] ?? c.gear).toLowerCase()}, ${(t.fuel[c.fuel] ?? c.fuel).toLowerCase()}, ${c.pax} seats. From ${c.price} € per day, VAT included.`
      : `Iznajmite ${c.name} u Novom Sadu: ${c.gear.toLowerCase()} menjač, ${c.fuel.toLowerCase()}, ${c.pax} putnika. Cena od ${c.price} € po danu, PDV uračunat.`,
    alternates: alts(lang, P.car('sr', slug), P.car('en', slug)),
    openGraph: c.image_url ? { images: [c.image_url] } : undefined,
  }
}
export async function CarDetail({ lang, slug }: { lang: Lang; slug: string }) {
  const [cars, s] = await Promise.all([getCars(), getSettings()])
  const c = cars.find((x) => x.slug === slug)
  if (!c) notFound()
  const h1 = lang === 'en' ? `${c.name} – car rental Novi Sad` : `${c.name} – rent a car Novi Sad`
  return (
    <section className="w two">
      {json({ '@context': 'https://schema.org', '@type': 'Product', name: h1, image: c.image_url ?? undefined, brand: s.brand,
        offers: { '@type': 'Offer', priceCurrency: 'EUR', price: c.price, availability: 'https://schema.org/InStock', url: site() + P.car(lang, c.slug) } })}
      <div className="car">
        {c.image_url ? <Image src={c.image_url} alt={h1} width={800} height={450} priority /> : <div className="ph">🚗</div>}
        <h1>{h1}</h1><Specs c={c} l={lang} /><Price c={c} l={lang} />
      </div>
      <BookingForm cars={light(cars)} defaultCar={c.id} lang={lang} />
    </section>
  )
}

function PostCard({ p, l }: { p: Post; l: Lang }) {
  const v = pv(p, l)
  return (
    <article className="card car">
      {p.image_url && <Image src={p.image_url} alt={v.title ?? ''} width={640} height={360} />}
      <small>{date(p.published_at, l)}</small>
      <h3><Link href={P.post(l, p.slug)}>{v.title}</Link></h3><p>{v.excerpt}</p>
      <Link href={P.post(l, p.slug)}>{T[l].read}</Link>
    </article>
  )
}
export async function newsMeta(lang: Lang): Promise<Metadata> {
  return { title: lang === 'en' ? 'News and car rental tips' : 'Vesti i saveti o iznajmljivanju automobila', alternates: alts(lang, '/vesti', '/en/news') }
}
export async function NewsIndex({ lang }: { lang: Lang }) {
  const posts = visible(await getPosts(), lang)
  return (
    <section className="w"><h1>{T[lang].newsTitle}</h1>
      {posts.length ? <div className="grid">{posts.map((p) => <PostCard key={p.id} p={p} l={lang} />)}</div> : <p>{T[lang].noNews}</p>}
    </section>
  )
}
export async function postMeta(lang: Lang, slug: string): Promise<Metadata> {
  const p = (await getPosts()).find((x) => x.slug === slug), v = p && pv(p, lang)
  if (!p || !v?.title) return {}
  return { title: v.title, description: v.excerpt ?? undefined, alternates: alts(lang, P.post('sr', slug), P.post('en', slug)),
    openGraph: { type: 'article', publishedTime: p.published_at, images: p.image_url ? [p.image_url] : undefined } }
}
export async function PostDetail({ lang, slug }: { lang: Lang; slug: string }) {
  const [posts, s] = await Promise.all([getPosts(), getSettings()])
  const p = posts.find((x) => x.slug === slug), v = p && pv(p, lang)
  if (!p || !v?.title) notFound()
  return (
    <article className="w narrow-article">
      {json({ '@context': 'https://schema.org', '@type': 'Article', headline: v.title, description: v.excerpt ?? undefined, datePublished: p.published_at, inLanguage: lang,
        image: p.image_url ?? undefined, author: { '@type': 'Organization', name: s.brand }, publisher: { '@type': 'Organization', name: s.brand } })}
      <p><Link href={P.news(lang)}>{T[lang].back}</Link></p>
      <h1>{v.title}</h1><small>{date(p.published_at, lang)}</small>
      {p.image_url && <Image src={p.image_url} alt={v.title} width={900} height={506} priority className="hero-img" />}
      {(v.body ?? '').split(/\n{2,}/).map((para, i) => <p key={i}>{para}</p>)}
    </article>
  )
}
