import { redirect } from 'next/navigation'
import { sessionDb } from './supabase'

export async function isAdmin() {
  const { data } = await (await sessionDb()).auth.getUser() // proverava token na Supabase serveru
  const admin = process.env.ADMIN_EMAIL?.toLowerCase()
  return !!admin && data.user?.email?.toLowerCase() === admin
}
/** Pozivati u SVAKOM admin layoutu, stranici i server akciji. */
export async function requireAdmin() {
  if (!(await isAdmin())) redirect('/admin/login')
}
