import { publicDb } from './supabase'

export type Settings = {
  brand: string; tag: string; hero: string; sub: string; about: string; phone: string; email: string; addr: string; hours: string
  firm_name: string; pib: string; mb: string; acc: string; why: string[][]; faq: string[][]
  tag_en?: string | null; hero_en?: string | null; sub_en?: string | null; about_en?: string | null; why_en?: string[][] | null; faq_en?: string[][] | null
}
export type Post = { id: string; slug: string; title: string; excerpt: string | null; body: string | null; image_url: string | null; title_en: string | null; excerpt_en: string | null; body_en: string | null; published: boolean; published_at: string }
export type Car = { id: string; slug: string; name: string; pax: number; bags: number; gear: string; fuel: string; price: number; image_url: string | null }
export type Reservation = { id: string; no: string; car_name: string; price: number; days: number; total: number; from_at: string; to_at: string; name: string; phone: string; email: string; status: string; created_at: string }
export type FormState = { ok: boolean; msg: string } | null

export const SETTING_FIELDS: [string, string][] = [
  ['brand', 'Naziv brenda'], ['tag', 'Podnaslov / SEO fraza'], ['hero', 'Glavni naslov (H1)'], ['sub', 'Tekst akcije'],
  ['phone', 'Telefon'], ['email', 'Email'], ['addr', 'Adresa'], ['hours', 'Radno vreme'],
  ['firm_name', 'Pravno lice (račun)'], ['pib', 'PIB'], ['mb', 'Matični broj'], ['acc', 'Tekući račun'],
]
export async function getSettings() {
  const { data } = await publicDb().from('settings').select('*').eq('id', 1).single()
  return data as Settings
}
export async function getCars() {
  const { data } = await publicDb().from('cars').select('*').order('sort').order('price')
  return (data ?? []) as Car[]
}
export const money = (n: number) => Number(n).toLocaleString('sr-Latn-RS', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €'
export const site = () => process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000'
export const fmt = (d: string) => new Date(d).toLocaleString('sr-Latn-RS', { dateStyle: 'short', timeStyle: 'short', timeZone: 'Europe/Belgrade' })
export const SETTING_FIELDS_EN: [string, string][] = [['tag_en', 'Subtitle / SEO phrase (EN)'], ['hero_en', 'Main heading H1 (EN)'], ['sub_en', 'Promo text (EN)']]
export async function getPosts() {
  const { data } = await publicDb().from('posts').select('*').order('published_at', { ascending: false }) // RLS: samo objavljeno
  return (data ?? []) as Post[]
}
