import type { Settings } from './data'

export type Lang = 'sr' | 'en'
const sr = {
  locale: 'sr-Latn-RS', day: 'dan', fleet: 'Vozni park', about: 'O nama', contact: 'Kontakt', news: 'Vesti', book: 'Rezervišite',
  fleetTitle: 'Izdvajamo iz naše rent a car ponude u Novom Sadu', whyTitle: 'Šta nas izdvaja', faqTitle: 'Česta pitanja', contactTitle: 'Kontaktirajte nas',
  phone: 'Telefon', email: 'Email', address: 'Adresa', hours: 'Radno vreme', pax: 'Putnika', bags: 'Kofera', from: 'od', perDay: '/ dan · PDV uračunat',
  check: 'Proverite raspoloživost', bookTitle: 'Rezervišite vozilo', car: 'Vozilo', pickup: 'Preuzimanje', ret: 'Vraćanje', name: 'Ime i prezime',
  send: 'Pošaljite rezervaciju', sending: 'Slanje…', newsTitle: 'Vesti i saveti', latest: 'Najnovije objave', read: 'Pročitajte →', noNews: 'Još nema objava.', back: '← Sve vesti', all: 'Sve objave →',
  badDates: 'Proverite izabrano vozilo i datume.', badContact: 'Proverite unete kontakt podatke.', fail: 'Došlo je do greške. Pokušajte ponovo ili nas pozovite.',
  thanks: (no: string) => `Hvala! Rezervacija ${no} je primljena – javićemo vam se uskoro.`,
  gear: {} as Record<string, string>, fuel: {} as Record<string, string>,
}
const en: typeof sr = {
  locale: 'en-GB', day: 'day', fleet: 'Fleet', about: 'About us', contact: 'Contact', news: 'News', book: 'Book now',
  fleetTitle: 'Featured cars from our Novi Sad car rental fleet', whyTitle: 'Why choose us', faqTitle: 'Frequently asked questions', contactTitle: 'Contact us',
  phone: 'Phone', email: 'Email', address: 'Address', hours: 'Opening hours', pax: 'Passengers', bags: 'Suitcases', from: 'from', perDay: '/ day · VAT included',
  check: 'Check availability', bookTitle: 'Book a car', car: 'Car', pickup: 'Pick-up', ret: 'Return', name: 'Full name',
  send: 'Send booking request', sending: 'Sending…', newsTitle: 'News and tips', latest: 'Latest posts', read: 'Read more →', noNews: 'No posts yet.', back: '← All news', all: 'All posts →',
  badDates: 'Please check the selected car and dates.', badContact: 'Please check your contact details.', fail: 'Something went wrong. Please try again or call us.',
  thanks: (no: string) => `Thank you! Booking ${no} has been received – we will contact you shortly.`,
  gear: { Automatski: 'Automatic', Manuelni: 'Manual' }, fuel: { Benzin: 'Petrol', Dizel: 'Diesel', Hibrid: 'Hybrid', Električni: 'Electric' },
}
export const T = { sr, en }
export const P = {
  home: (l: Lang) => (l === 'en' ? '/en' : '/'),
  car: (l: Lang, s: string) => (l === 'en' ? `/en/fleet/${s}` : `/vozni-park/${s}`),
  news: (l: Lang) => (l === 'en' ? '/en/news' : '/vesti'),
  post: (l: Lang, s: string) => (l === 'en' ? `/en/news/${s}` : `/vesti/${s}`),
}
const ext = (s: Settings) => s as unknown as Record<string, unknown>
export const tx = (s: Settings, k: 'tag' | 'hero' | 'sub' | 'about', l: Lang) => (l === 'en' && (ext(s)[k + '_en'] as string)) || s[k]
export const tl = (s: Settings, k: 'why' | 'faq', l: Lang) => {
  const v = ext(s)[k + '_en'] as string[][] | undefined
  return (l === 'en' && v?.length ? v : s[k]) as string[][]
}
