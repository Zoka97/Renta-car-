import type { Metadata } from 'next'
import { getSettings, site } from './data'
import { tx, type Lang } from './i18n'

export async function rootMeta(lang: Lang): Promise<Metadata> {
  const s = await getSettings()
  const en = lang === 'en'
  return {
    metadataBase: new URL(site()),
    title: { default: en ? `${s.brand} – ${tx(s, 'tag', 'en')} | Car hire` : `${s.brand} – ${s.tag} | Iznajmljivanje vozila`, template: `%s | ${s.brand}` },
    description: en ? `${s.brand} – ${tx(s, 'tag', 'en')}. ${tx(s, 'sub', 'en')}. VAT-inclusive prices and online booking.` : `${s.brand} – ${s.tag}. ${s.sub}. Transparentne cene sa PDV-om i online rezervacija.`,
    openGraph: { type: 'website', locale: en ? 'en_US' : 'sr_RS', siteName: s.brand },
    robots: { index: true, follow: true },
  }
}
/** canonical + hreflang za par stranica SR/EN */
export const alts = (lang: Lang, sr: string, en: string) => ({ canonical: lang === 'en' ? en : sr, languages: { 'sr-RS': sr, en } })
