import { PDFDocument, rgb } from 'pdf-lib'
import fontkit from '@pdf-lib/fontkit'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fmt, money, type Reservation, type Settings } from './data'

/** PDF potvrda sa računom. DejaVu Sans podržava č, ć, š, ž, đ. */
export async function buildPdf(r: Reservation, s: Settings) {
  const pdf = await PDFDocument.create()
  pdf.registerFontkit(fontkit)
  const dir = path.join(process.cwd(), 'assets', 'fonts')
  const reg = await pdf.embedFont(await readFile(path.join(dir, 'DejaVuSans.ttf')), { subset: true })
  const bold = await pdf.embedFont(await readFile(path.join(dir, 'DejaVuSans-Bold.ttf')), { subset: true })
  const W = 595.28, H = 841.89, p = pdf.addPage([W, H])
  const navy = rgb(0.059, 0.165, 0.29), acc = rgb(0.96, 0.65, 0.14), ink = rgb(0.08, 0.12, 0.18), gray = rgb(0.36, 0.42, 0.49), white = rgb(1, 1, 1)
  const t = (text: string, x: number, y: number, size = 10, b = false, color = ink, align: 'l' | 'r' | 'c' = 'l') => {
    const f = b ? bold : reg, w = f.widthOfTextAtSize(text, size)
    p.drawText(text, { x: align === 'r' ? x - w : align === 'c' ? x - w / 2 : x, y, size, font: f, color })
  }
  p.drawRectangle({ x: 0, y: H - 120, width: W, height: 120, color: navy })
  p.drawSvgPath('M8 30Q24 6 40 30', { x: 40, y: H - 38, scale: 1.6, borderColor: acc, borderWidth: 2.4 })
  p.drawSvgPath('M6 37q4.5-4 9 0t9 0t9 0t9 0', { x: 40, y: H - 38, scale: 1.6, borderColor: white, borderWidth: 2 })
  t(s.brand, 130, H - 58, 22, true, white); t(s.tag, 130, H - 78, 10, false, rgb(0.62, 0.76, 0.93))
  t('POTVRDA REZERVACIJE I RAČUN', W - 40, H - 54, 12, true, acc, 'r')
  t(`Br. ${r.no} · ${new Date(r.created_at).toLocaleDateString('sr-Latn-RS', { timeZone: 'Europe/Belgrade' })}`, W - 40, H - 74, 10, false, white, 'r')

  t('IZDAVALAC', 40, H - 160, 9, true, gray)
  ;[s.firm_name, s.addr, `PIB: ${s.pib} · MB: ${s.mb}`, `Tekući račun: ${s.acc}`, `${s.phone} · ${s.email}`].forEach((l, i) => t(l, 40, H - 178 - i * 15, i ? 10 : 12, !i))
  t('KLIJENT', 340, H - 160, 9, true, gray)
  ;[r.name, r.phone, r.email].forEach((l, i) => t(l, 340, H - 178 - i * 15, i ? 10 : 12, !i))

  p.drawRectangle({ x: 40, y: H - 320, width: W - 80, height: 26, color: navy })
  ;([['Vozilo', 48, 'l'], ['Period najma', 190, 'l'], ['Dana', 380, 'l'], ['Cena/dan', 420, 'l'], ['Iznos', W - 48, 'r']] as const).forEach(([x, px, a]) => t(x, px, H - 311, 9, true, white, a))
  t(r.car_name, 48, H - 345, 11, true); t(`${fmt(r.from_at)} → ${fmt(r.to_at)}`, 190, H - 345, 9)
  t(String(r.days), 380, H - 345, 11); t(money(r.price), 420, H - 345, 10); t(money(r.total), W - 48, H - 345, 11, true, ink, 'r')
  p.drawLine({ start: { x: 40, y: H - 360 }, end: { x: W - 40, y: H - 360 }, thickness: 0.8, color: rgb(0.87, 0.89, 0.93) })

  const base = r.total / 1.2
  t('Osnovica', W - 170, H - 385, 10, false, gray, 'r'); t(money(base), W - 48, H - 385, 10, false, ink, 'r')
  t('PDV 20%', W - 170, H - 403, 10, false, gray, 'r'); t(money(r.total - base), W - 48, H - 403, 10, false, ink, 'r')
  p.drawRectangle({ x: W - 270, y: H - 442, width: 230, height: 28, color: acc })
  t('UKUPNO', W - 260, H - 432, 11, true, rgb(0.1, 0.07, 0)); t(money(r.total), W - 48, H - 432, 13, true, rgb(0.1, 0.07, 0), 'r')

  t('Napomene', 40, H - 500, 10, true)
  ;['Cene su izražene u evrima i uključuju PDV.', 'Vozilo se preuzima uz važeću vozačku dozvolu i lični dokument.', `Za izmene ili otkazivanje rezervacije pozovite ${s.phone}.`]
    .forEach((l, i) => t('• ' + l, 40, H - 520 - i * 16, 9.5, false, gray))
  t(`Dokument je elektronski generisan i važi bez pečata i potpisa. · ${s.brand} – ${s.tag}`, W / 2, 30, 8, false, gray, 'c')
  return pdf.save()
}
