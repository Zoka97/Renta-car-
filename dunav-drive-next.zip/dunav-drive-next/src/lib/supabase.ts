import { createServerClient } from '@supabase/ssr'
import { createClient } from '@supabase/supabase-js'
import { cookies } from 'next/headers'

const url = process.env.NEXT_PUBLIC_SUPABASE_URL!
const pub = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!

/** Javno čitanje (vozila, podešavanja) – može u statičke stranice. */
export const publicDb = () => createClient(url, pub, { auth: { persistSession: false } })
/** Samo na serveru, posle provere admina. Zaobilazi RLS. */
export const serviceDb = () => createClient(url, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } })
/** Klijent sa korisničkom sesijom (kolačići) – za prijavu. */
export async function sessionDb() {
  const jar = await cookies()
  return createServerClient(url, pub, {
    cookies: {
      getAll: () => jar.getAll(),
      setAll: (list) => { try { list.forEach(({ name, value, options }) => jar.set(name, value, options)) } catch {} },
    },
  })
}
