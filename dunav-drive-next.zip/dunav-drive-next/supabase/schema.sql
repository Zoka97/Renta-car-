create table settings (
  id int primary key default 1 check (id = 1),
  brand text, tag text, hero text, sub text, about text, phone text, email text, addr text, hours text,
  firm_name text, pib text, mb text, acc text, why jsonb default '[]', faq jsonb default '[]'
);
create table cars (
  id uuid primary key default gen_random_uuid(), slug text unique not null, name text not null,
  pax int default 5, bags int default 2, gear text, fuel text, price numeric not null, image_url text, sort int default 0
);
create table reservations (
  id uuid primary key default gen_random_uuid(), no text unique not null, car_name text not null,
  price numeric not null, days int not null, total numeric not null, from_at timestamptz not null, to_at timestamptz not null,
  name text not null, phone text not null, email text not null, status text default 'nova', created_at timestamptz default now()
);
alter table settings enable row level security;
alter table cars enable row level security;
alter table reservations enable row level security;  -- bez politika: samo server (service role) pristupa
create policy "javno citanje podesavanja" on settings for select using (true);
create policy "javno citanje vozila" on cars for select using (true);
insert into storage.buckets (id, name, public) values ('cars', 'cars', true) on conflict do nothing;

insert into settings values (1, 'Dunav Drive', 'Rent a car Novi Sad', 'Dunav Drive, rent a car u Novom Sadu – više od očekivanja',
 'Aktuelni popusti do 20% na dugoročni najam vozila',
 'Dunav Drive je novosadska rent a car kompanija koja spaja moderna, uredna vozila i transparentne uslove. Bilo da vam treba automobil za dan, nedelju ili dugoročni najam, tu smo da pronađemo najbolje rešenje za vaše potrebe – bez skrivenih troškova.',
 '+381 21 000 000', 'rent@dunavdrive.rs', 'Bulevar oslobođenja 100, Novi Sad', 'Svaki dan 08:00 – 20:00',
 'Dunav Drive d.o.o.', '000000000', '00000000', '160-0000000000000-00',
 '[["Fantastična ponuda","Povoljne cene i aktuelni popusti, bez skrivenih troškova."],["Veliki izbor vozila","Od gradskih do premium modela, za svaku priliku i budžet."],["Jednostavna rezervacija","Rezervišite online za nekoliko minuta, bez nepotrebnih koraka."],["Profesionalni pristup","Ljubazan tim i uredna vozila, uvek spremna za preuzimanje."]]',
 '[["Šta je potrebno za iznajmljivanje automobila u Novom Sadu?","Važeća vozačka dozvola, lična karta ili pasoš i kreditna ili debitna kartica."],["Da li su cene sa PDV-om?","Da, sve prikazane cene uključuju PDV, bez dodatne naplate i skrivenih troškova."],["Mogu li da preuzmem vozilo van radnog vremena?","Dogovorite termin sa nama telefonom ili emailom, rado ćemo se prilagoditi."],["Postoji li popust za duži najam?","Da, što je najam duži, to je cena po danu povoljnija. Javite nam se za ponudu."]]');
insert into cars (slug, name, pax, bags, gear, fuel, price, sort) values
 ('skoda-fabia', 'Škoda Fabia', 5, 1, 'Manuelni', 'Benzin', 19, 1),
 ('toyota-yaris-cross', 'Toyota Yaris Cross', 5, 1, 'Automatski', 'Hibrid', 22, 2),
 ('vw-t-cross-dsg', 'VW T-Cross DSG', 5, 2, 'Automatski', 'Benzin', 25, 3),
 ('vw-t-roc', 'VW T-Roc', 5, 2, 'Automatski', 'Benzin', 35, 4);
