-- Pokrenuti POSLE schema.sql: engleski sadržaj + vesti
alter table settings
  add column if not exists tag_en text, add column if not exists hero_en text, add column if not exists sub_en text,
  add column if not exists about_en text, add column if not exists why_en jsonb default '[]', add column if not exists faq_en jsonb default '[]';
update settings set
  tag_en = 'Car rental Novi Sad',
  hero_en = 'Dunav Drive, car rental in Novi Sad – more than you expect',
  sub_en = 'Current discounts of up to 20% on long-term rentals',
  about_en = 'Dunav Drive is a Novi Sad car rental company that combines modern, well-kept vehicles with transparent terms. Whether you need a car for a day, a week or a long-term rental, we will find the best solution for your needs – with no hidden costs.',
  why_en = '[["Great offers","Affordable prices and current discounts, with no hidden costs."],["Wide choice of vehicles","From city cars to premium models, for every occasion and budget."],["Easy booking","Book online in a few minutes, with no unnecessary steps."],["Professional service","A friendly team and clean vehicles, always ready for pickup."]]',
  faq_en = '[["What do I need to rent a car in Novi Sad?","A valid driving licence, an ID card or passport, and a credit or debit card."],["Are the prices VAT included?","Yes, all prices include VAT, with no extra charges or hidden costs."],["Can I pick up a car outside working hours?","Arrange a time with us by phone or email and we will gladly accommodate you."],["Is there a discount for longer rentals?","Yes, the longer the rental, the lower the daily rate. Contact us for an offer."]]'
where id = 1;
create table if not exists posts (
  id uuid primary key default gen_random_uuid(), slug text unique not null, title text not null, excerpt text, body text, image_url text,
  title_en text, excerpt_en text, body_en text, published boolean default false, published_at timestamptz default now()
);
alter table posts enable row level security;
create policy "javno citanje objavljenih" on posts for select using (published);
